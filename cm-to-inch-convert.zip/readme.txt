=== Cm to Inch Convert===
Contributors: ensky
Donate link: https://paypal.me/enskytech
Requires at least: 5.2
Tested up to: 5.3.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

CM to inches converter. Easily convert Centimeters to Inches



### Plugin Features
1. install plugin, enable it.
2. use short code: [convert_cm_to_inch_shortcode]
3. it will show two input box, can convert cm to inch


== Installation ==


== Screenshots ==


= Minimum Requirements =

* WordPress 4.9 or greater
* PHP version 5.2.4 or greater

== Changelog ==

= 1.0.0 =
----------------------------------------------------------------------
 - The first version
